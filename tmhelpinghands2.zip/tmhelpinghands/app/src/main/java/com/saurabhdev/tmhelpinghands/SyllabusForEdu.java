package com.saurabhdev.tmhelpinghands;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SyllabusForEdu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_syllabus_for_edu);
    }
}